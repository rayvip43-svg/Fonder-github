/* ======================= Routing ======================= */
var VIEWS = ['home','transfer','qris','pay','topup','invest','history','profile'];
var TAB_VIEWS = ['home','history','qris','invest','profile'];

function go(name){
  if(VIEWS.indexOf(name) === -1) name = 'home';
  VIEWS.forEach(function(v){
    var panel = document.getElementById('panel-' + v);
    if(panel) panel.classList.toggle('active', v === name);
  });
  document.querySelectorAll('.tab-btn').forEach(function(btn){
    btn.classList.toggle('active', btn.dataset.tab === name);
  });
  if(TAB_VIEWS.indexOf(name) !== -1){
    try { location.hash = name; } catch(e){}
  }
  window.scrollTo(0,0);
}
function initRoute(){
  var h = (location.hash || '').replace('#','');
  go(VIEWS.indexOf(h) !== -1 ? h : 'home');
}
window.addEventListener('hashchange', initRoute);

/* ======================= Toast ======================= */
var toastTimer = null;
function toast(msg, isWarn){
  var el = document.getElementById('toastEl');
  el.textContent = msg;
  el.classList.toggle('warn', !!isWarn);
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(function(){ el.classList.remove('show'); }, 2400);
}

/* ======================= State (persisted) ======================= */
var STORE_KEY = 'fonder_state_v1';
var state = null;

function defaultState(){
  return {
    balance: 2450000,
    investTotal: 850000,
    notifCount: 0,
    tx: [
      { id: 't5', name: 'Terima dari Rudi D.', sub: '15 Nov · 11:02', amount: 200000, type: 'in' },
      { id: 't4', name: 'Tagihan Listrik', sub: '18 Nov · 08:21', amount: -245000, type: 'out' },
      { id: 't3', name: 'QRIS - Kopi Senja', sub: '20 Nov · 15:40', amount: -28000, type: 'out' },
      { id: 't2', name: 'Top Up dari BCA', sub: '20 Nov · 20:02', amount: 500000, type: 'in' },
      { id: 't1', name: 'Transfer ke Siti A.', sub: '21 Nov · 09:14', amount: -150000, type: 'out' }
    ]
  };
}

function loadState(){
  try{
    var raw = localStorage.getItem(STORE_KEY);
    if(raw) return JSON.parse(raw);
  }catch(e){}
  return defaultState();
}
function saveState(){
  try{ localStorage.setItem(STORE_KEY, JSON.stringify(state)); }catch(e){}
}
function resetDemo(){
  state = defaultState();
  saveState();
  hiddenBalance = false;
  renderAll();
  toast('Data demo direset ke kondisi awal');
}

/* ======================= Formatting ======================= */
function fmt(n){
  var sign = n < 0 ? '-' : '';
  return sign + 'Rp\u00a0' + Math.abs(Math.round(n)).toLocaleString('id-ID');
}
function parseAmount(str){
  if(!str) return 0;
  var n = parseInt(String(str).replace(/[^0-9]/g,''), 10);
  return isNaN(n) ? 0 : n;
}
function nowLabel(){
  var d = new Date();
  var hh = String(d.getHours()).padStart(2,'0');
  var mm = String(d.getMinutes()).padStart(2,'0');
  return 'Baru saja · ' + hh + ':' + mm;
}

/* ======================= Transactions ======================= */
function addTransaction(name, signedAmount){
  var tx = {
    id: 'tx_' + Date.now(),
    name: name,
    sub: nowLabel(),
    amount: signedAmount,
    type: signedAmount >= 0 ? 'in' : 'out'
  };
  state.tx.unshift(tx);
  state.balance += signedAmount;
  state.notifCount += 1;
  saveState();
  renderAll();
}

function txIcon(type){
  return type === 'in'
    ? '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12l7 7 7-7"/></svg>'
    : '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 19V5M5 12l7-7 7 7"/></svg>';
}

function escapeAttr(s){ return String(s).replace(/'/g, "\\'"); }

function renderTxRow(tx){
  return '<button class="tx-row" data-type="' + tx.type + '" onclick="toast(\'' + escapeAttr(tx.name) + ' · ' + fmt(Math.abs(tx.amount)) + '\')">' +
    '<div class="tx-ic ' + tx.type + '">' + txIcon(tx.type) + '</div>' +
    '<div class="tx-main"><div class="tx-name">' + tx.name + '</div><div class="tx-sub">' + tx.sub + '</div></div>' +
    '<div class="tx-amt ' + tx.type + ' tabular">' + fmt(tx.amount) + '</div>' +
  '</button>';
}

function renderHome(){
  var list = state.tx.slice(0,4);
  var el = document.getElementById('homeTxList');
  el.innerHTML = list.length ? list.map(renderTxRow).join('') : '<div class="empty-note">Belum ada transaksi</div>';
}

var historyFilter = 'all';
function renderHistory(){
  var el = document.getElementById('historyList');
  var filtered = state.tx.filter(function(t){ return historyFilter === 'all' || t.type === historyFilter; });
  el.innerHTML = filtered.length ? filtered.map(renderTxRow).join('') : '<div class="empty-note">Tidak ada transaksi pada kategori ini</div>';
}
function filterHistory(btn, type){
  historyFilter = type;
  document.querySelectorAll('#historyPills .pill').forEach(function(p){ p.classList.remove('active'); });
  btn.classList.add('active');
  renderHistory();
}

var hiddenBalance = false;
function renderBalance(){
  document.getElementById('balanceAmt').textContent = hiddenBalance ? 'Rp •••••••' : fmt(state.balance);
}
function renderInvest(){
  document.getElementById('investTotal').textContent = fmt(state.investTotal);
}
function renderNotif(){
  document.getElementById('notifDot').classList.toggle('show', state.notifCount > 0);
}
function renderAll(){
  renderBalance();
  renderHome();
  renderHistory();
  renderInvest();
  renderNotif();
}

document.getElementById('eyeBtn').addEventListener('click', function(){
  hiddenBalance = !hiddenBalance;
  renderBalance();
});

function openNotif(){
  state.notifCount = 0;
  saveState();
  renderNotif();
  toast('Semua notifikasi sudah dibaca');
}

/* ======================= Set balance (demo) ======================= */
function applySetBalance(){
  var input = document.getElementById('setBalanceInput');
  var amount = parseAmount(input.value);
  if(amount < 0){
    toast('Nominal tidak valid', true);
    return;
  }
  state.balance = amount;
  saveState();
  renderAll();
  toast('Saldo diatur ke ' + fmt(amount));
  input.value = '';
}

/* ======================= Generic pill selector ======================= */
function selectPill(btn, groupId){
  document.querySelectorAll('#' + groupId + ' .pill').forEach(function(p){ p.classList.remove('active'); });
  btn.classList.add('active');
}

/* ======================= Transfer ======================= */
function fillTransfer(el, name, number){
  document.getElementById('transferNumber').value = number;
  document.querySelectorAll('#panel-transfer .contact-row').forEach(function(r){ r.classList.remove('selected'); });
  el.classList.add('selected');
  toast('Kontak dipilih: ' + name);
}
function submitTransfer(){
  var numEl = document.getElementById('transferNumber');
  var amtEl = document.getElementById('transferAmount');
  var num = numEl.value.trim();
  var amount = parseAmount(amtEl.value);
  var err = document.getElementById('transferErr');
  if(!num || !amount){
    err.textContent = 'Lengkapi nomor tujuan dan nominal terlebih dahulu.';
    err.classList.add('show');
    return;
  }
  if(amount > state.balance){
    err.textContent = 'Saldo tidak cukup. Saldo kamu saat ini ' + fmt(state.balance) + '.';
    err.classList.add('show');
    toast('Transfer gagal: saldo tidak cukup', true);
    return;
  }
  err.classList.remove('show');
  var type = document.querySelector('#transferTypePills .pill.active').dataset.val;
  requestPin({
    title: 'Konfirmasi Transfer',
    subtitle: 'Transfer ' + fmt(amount) + ' ke ' + num,
    onSuccess: function(){
      addTransaction('Transfer ke ' + num, -amount);
      showSheet({
        title: 'Transfer Berhasil',
        desc: 'Saldo kamu telah diperbarui.',
        rows: [
          ['Jenis', type],
          ['Tujuan', num],
          ['Nominal', fmt(amount)],
          ['Sisa Saldo', fmt(state.balance)]
        ]
      });
      numEl.value = '';
      amtEl.value = '';
    }
  });
}

/* ======================= QRIS ======================= */
function switchQris(btn, which){
  document.querySelectorAll('#qrisPills .pill').forEach(function(p){ p.classList.remove('active'); });
  btn.classList.add('active');
  document.getElementById('qrisScanView').style.display = which === 'scan' ? 'flex' : 'none';
  document.getElementById('qrisMineView').style.display = which === 'mine' ? 'flex' : 'none';
}
function simulateScan(){
  var amount = parseAmount(document.getElementById('qrisAmount').value);
  if(!amount){
    toast('Masukkan nominal pembayaran', true);
    return;
  }
  if(amount > state.balance){
    toast('Pembayaran gagal: saldo tidak cukup', true);
    return;
  }
  toast('Memindai kode QRIS...');
  setTimeout(function(){
    var merchant = 'Kopi Senja';
    requestPin({
      title: 'Konfirmasi QRIS',
      subtitle: 'Bayar ' + fmt(amount) + ' ke ' + merchant,
      onSuccess: function(){
        addTransaction('QRIS - ' + merchant, -amount);
        showSheet({
          title: 'Pembayaran QRIS Berhasil',
          desc: 'Transaksi telah dicatat ke riwayat.',
          rows: [
            ['Merchant', merchant],
            ['Nominal', fmt(amount)],
            ['Sisa Saldo', fmt(state.balance)]
          ]
        });
      }
    });
  }, 900);
}

/* ======================= Tagihan (custom nominal) ======================= */
var amountSheetConfirmCb = null;
var amountSheetMin = 0;
function showAmountEntrySheet(cfg){
  amountSheetConfirmCb = cfg.onConfirm;
  amountSheetMin = cfg.min || 0;
  var body = document.getElementById('sheetBody');
  body.innerHTML =
    '<div class="sheet-icon"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 7h16v12H4zM4 11h16"/></svg></div>' +
    '<h2>' + cfg.title + '</h2>' +
    '<p>' + cfg.subtitle + '</p>' +
    '<div class="field"><label>Nominal</label><input id="amountSheetInput" inputmode="numeric" value="' + (cfg.initialAmount ? cfg.initialAmount.toLocaleString('id-ID') : '') + '" placeholder="Rp 0"></div>' +
    '<span class="field-err" id="amountSheetErr">Masukkan nominal yang valid.</span>' +
    '<div class="sheet-row"><span class="k">Saldo Saat Ini</span><span class="v">' + fmt(state.balance) + '</span></div>' +
    '<button class="btn" style="margin-top:14px;" onclick="confirmAmountSheet()">Lanjutkan</button>';
  document.getElementById('sheetBackdrop').classList.add('show');
}
function confirmAmountSheet(){
  var input = document.getElementById('amountSheetInput');
  var amount = parseAmount(input.value);
  var err = document.getElementById('amountSheetErr');
  if(!amount || amount < amountSheetMin){
    err.textContent = amountSheetMin ? ('Minimum nominal ' + fmt(amountSheetMin) + '.') : 'Masukkan nominal yang valid.';
    err.classList.add('show');
    return;
  }
  if(amount > state.balance){
    err.textContent = 'Saldo tidak cukup. Saldo kamu ' + fmt(state.balance) + '.';
    err.classList.add('show');
    return;
  }
  err.classList.remove('show');
  closeSheet();
  var cb = amountSheetConfirmCb;
  if(cb) cb(amount);
}

function openBill(category, suggested){
  showAmountEntrySheet({
    title: 'Bayar ' + category,
    subtitle: 'Masukkan nominal tagihan ' + category + '.',
    initialAmount: suggested,
    onConfirm: function(amount){
      requestPin({
        title: 'Konfirmasi Pembayaran',
        subtitle: 'Bayar tagihan ' + category + ' · ' + fmt(amount),
        onSuccess: function(){
          addTransaction('Tagihan ' + category, -amount);
          showSheet({
            title: 'Pembayaran Berhasil',
            desc: 'Tagihan ' + category + ' telah dibayar.',
            rows: [['Nominal', fmt(amount)], ['Sisa Saldo', fmt(state.balance)]]
          });
        }
      });
    }
  });
}

/* ======================= Top Up ======================= */
function setTopupAmount(v){
  document.getElementById('topupAmount').value = v.toLocaleString('id-ID');
}
function selectMethod(btn){
  document.querySelectorAll('#topupMethods .contact-row').forEach(function(r){ r.classList.remove('selected'); });
  btn.classList.add('selected');
}
function submitTopup(){
  var amtEl = document.getElementById('topupAmount');
  var amount = parseAmount(amtEl.value);
  var methodEl = document.querySelector('#topupMethods .contact-row.selected');
  var err = document.getElementById('topupErr');
  if(!amount || !methodEl){
    err.textContent = 'Pilih nominal atau isi sendiri, lalu pilih metode.';
    err.classList.add('show');
    return;
  }
  err.classList.remove('show');
  addTransaction('Top Up via ' + methodEl.dataset.method, amount);
  showSheet({
    title: 'Top Up Berhasil',
    desc: 'Saldo kamu telah ditambahkan.',
    rows: [
      ['Metode', methodEl.dataset.method],
      ['Nominal', fmt(amount)],
      ['Saldo Sekarang', fmt(state.balance)]
    ]
  });
  amtEl.value = '';
  document.querySelectorAll('#topupMethods .contact-row').forEach(function(r){ r.classList.remove('selected'); });
}

/* ======================= Invest (custom nominal) ======================= */
function openInvest(productName, minAmount){
  showAmountEntrySheet({
    title: 'Mulai ' + productName,
    subtitle: 'Minimum pembelian ' + fmt(minAmount) + '.',
    initialAmount: minAmount,
    min: minAmount,
    onConfirm: function(amount){
      requestPin({
        title: 'Konfirmasi Investasi',
        subtitle: productName + ' · ' + fmt(amount),
        onSuccess: function(){
          state.balance -= amount;
          state.investTotal += amount;
          state.tx.unshift({ id: 'tx_' + Date.now(), name: 'Investasi ' + productName, sub: nowLabel(), amount: -amount, type: 'out' });
          state.notifCount += 1;
          saveState();
          renderAll();
          showSheet({
            title: 'Pembelian Berhasil',
            desc: productName,
            rows: [
              ['Nominal', fmt(amount)],
              ['Total Investasi', fmt(state.investTotal)],
              ['Sisa Saldo', fmt(state.balance)]
            ]
          });
        }
      });
    }
  });
}

/* ======================= Logout ======================= */
function openLogoutSheet(){
  showSheet({
    title: 'Keluar dari Fonder?',
    desc: 'Kamu perlu memasukkan PIN lagi saat masuk berikutnya.',
    rows: [],
    primaryLabel: 'Ya, Keluar',
    secondaryLabel: 'Batal',
    onPrimary: function(){
      closeSheet();
      toast('Berhasil keluar (simulasi)');
      setTimeout(function(){
        requestPin({
          title: 'Masuk ke Fonder',
          subtitle: 'Masukkan PIN untuk melanjutkan',
          lock: true,
          onSuccess: function(){ go('home'); }
        });
      }, 400);
    }
  });
}

/* ======================= Bottom sheet (generic) ======================= */
var sheetPrimaryAction = null;
function showSheet(cfg){
  var body = document.getElementById('sheetBody');
  var rowsHtml = (cfg.rows || []).map(function(r){
    return '<div class="sheet-row"><span class="k">' + r[0] + '</span><span class="v">' + r[1] + '</span></div>';
  }).join('');
  sheetPrimaryAction = cfg.onPrimary || null;
  var primaryLabel = cfg.primaryLabel || 'Selesai';
  var actionsHtml = '<div class="stack" style="margin-top:4px;">' +
    '<button class="btn" onclick="runSheetPrimary()">' + primaryLabel + '</button>' +
    (cfg.secondaryLabel ? '<button class="btn ghost" onclick="closeSheet()">' + cfg.secondaryLabel + '</button>' : '') +
  '</div>';
  body.innerHTML =
    '<div class="sheet-icon"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 6L9 17l-5-5"/></svg></div>' +
    '<h2>' + cfg.title + '</h2>' +
    '<p>' + cfg.desc + '</p>' +
    rowsHtml +
    actionsHtml;
  document.getElementById('sheetBackdrop').classList.add('show');
}
function runSheetPrimary(){
  if(sheetPrimaryAction){ sheetPrimaryAction(); }
  else { closeSheet(); }
}
function closeSheet(){
  document.getElementById('sheetBackdrop').classList.remove('show');
}

/* ======================= More menu ======================= */
function openMoreMenu(){
  var items = [
    { label:'Mutasi Rekening', icon:'<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 7h16M4 12h10M4 17h16"/></svg>', action:"go(&#39;history&#39;);closeSheet();" },
    { label:'Kartu Saya', icon:'<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="5" width="16" height="14" rx="2"/><path d="M4 10h16"/></svg>', action:"go(&#39;profile&#39;);closeSheet();" },
    { label:'Pengaturan', icon:'<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M4 12h2M18 12h2M12 4v2M12 18v2M6.3 6.3l1.4 1.4M16.3 16.3l1.4 1.4M17.7 6.3l-1.4 1.4M7.7 16.3l-1.4 1.4"/></svg>', action:"go(&#39;profile&#39;);closeSheet();" },
    { label:'Split Bill', icon:'<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="7" r="3"/><path d="M2 21v-2a4 4 0 014-4h4a4 4 0 014 4v2"/><path d="M19 8v6M16 11h6"/></svg>', action:"openSplit();" },
    { label:'Gift Card', icon:'<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="8" width="18" height="13" rx="2"/><path d="M3 12h18M12 8v13"/></svg>', action:"closeSheet();toast(&#39;Fitur Gift Card belum tersedia di prototipe ini&#39;);" },
    { label:'Bahasa', icon:'<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M3 12h18"/><path d="M12 3a15 15 0 010 18"/></svg>', action:"closeSheet();toast(&#39;Bahasa saat ini: Indonesia&#39;);" }
  ];
  var html = '<h2 style="margin-bottom:4px;">Menu Lainnya</h2><p>Akses cepat ke fitur tambahan Fonder</p><div class="grid-menu">';
  items.forEach(function(it){
    html += '<button class="grid-item" onclick="' + it.action + '"><span class="grid-ic">' + it.icon + '</span><span class="grid-label">' + it.label + '</span></button>';
  });
  html += '</div>';
  document.getElementById('sheetBody').innerHTML = html;
  document.getElementById('sheetBackdrop').classList.add('show');
}

/* ======================= PIN overlay ======================= */
var pinBuffer = '';
var pinSuccessCb = null;
var pinCancelCb = null;
var APP_PIN = '123';

function requestPin(cfg){
  pinBuffer = '';
  pinSuccessCb = cfg.onSuccess || null;
  pinCancelCb = cfg.onCancel || null;
  document.getElementById('pinTitle').textContent = cfg.title || 'Masukkan PIN';
  document.getElementById('pinSubtitle').textContent = cfg.subtitle || 'Masukkan PIN untuk melanjutkan';
  document.getElementById('pinError').classList.remove('show');
  document.getElementById('pinCloseBtn').style.display = cfg.lock ? 'none' : 'flex';
  updatePinDots();
  document.getElementById('pinOverlay').classList.add('show');
}
function updatePinDots(){
  document.querySelectorAll('#pinDots .pin-dot').forEach(function(d,i){
    d.classList.toggle('filled', i < pinBuffer.length);
  });
}
function pinPress(d){
  if(pinBuffer.length >= 3) return;
  pinBuffer += d;
  updatePinDots();
  if(pinBuffer.length === 3){
    setTimeout(checkPin, 150);
  }
}
function pinBackspace(){
  pinBuffer = pinBuffer.slice(0, -1);
  updatePinDots();
  document.getElementById('pinError').classList.remove('show');
}
function checkPin(){
  if(pinBuffer === APP_PIN){
    document.getElementById('pinOverlay').classList.remove('show');
    var cb = pinSuccessCb;
    pinBuffer = '';
    updatePinDots();
    if(cb) cb();
  } else {
    document.getElementById('pinError').classList.add('show');
    pinBuffer = '';
    updatePinDots();
    var card = document.getElementById('pinCard');
    card.classList.add('shake');
    setTimeout(function(){ card.classList.remove('shake'); }, 320);
  }
}
function cancelPin(){
  document.getElementById('pinOverlay').classList.remove('show');
  pinBuffer = '';
  updatePinDots();
  if(pinCancelCb) pinCancelCb();
}

/* ======================= Fitur tambahan ======================= */
var CAT_COLOR = {'Transfer':'#FF7A1A','QRIS':'#2F7DD1','Tagihan':'#8B5CF6','Investasi':'#1F9254','Tabungan':'#E0457B','Top Up':'#14A3A3'};
var SUN = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>';
var MOON = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12.8A9 9 0 1111.2 3a7 7 0 009.8 9.8z"/></svg>';
function esc(s){ return String(s).replace(/[&<>"]/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]; }); }
function catOf(t){
  var n = t.name;
  if(/^(Terima|Transfer|Patungan)/.test(n)) return 'Transfer';
  if(/^QRIS/.test(n)) return 'QRIS';
  if(/^Tagihan/.test(n)) return 'Tagihan';
  if(/^Investasi/.test(n)) return 'Investasi';
  if(/^Tabungan/.test(n)) return 'Tabungan';
  return 'Top Up';
}
function defaultGoals(){ return [
  { id:'g1', name:'Liburan Bali', target:5000000, saved:1250000 },
  { id:'g2', name:'Laptop Baru', target:12000000, saved:3600000 }
]; }
var _ds = defaultState;
defaultState = function(){ var s = _ds(); s.goals = defaultGoals(); s.theme = null; return s; };
function ensureState(){ if(!state.goals) state.goals = defaultGoals(); }

/* Tema */
function effTheme(){ return (state && state.theme) || (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'); }
function applyTheme(){
  var th = effTheme();
  document.documentElement.setAttribute('data-theme', th);
  var b = document.getElementById('themeBtn');
  if(b){ b.innerHTML = th === 'dark' ? SUN : MOON; b.setAttribute('aria-label', th === 'dark' ? 'Pakai tema terang' : 'Pakai tema gelap'); }
}
function toggleTheme(){ state.theme = effTheme() === 'dark' ? 'light' : 'dark'; saveState(); applyTheme(); }

/* Sapaan */
function renderGreet(){
  var h = new Date().getHours();
  var s = h < 11 ? 'Selamat pagi' : h < 15 ? 'Selamat siang' : h < 18 ? 'Selamat sore' : 'Selamat malam';
  document.getElementById('greetEl').textContent = s + ', Rayhan';
}

/* Saldo dengan animasi hitung */
var shownBal = null;
function renderBalance(){
  var el = document.getElementById('balanceAmt');
  if(hiddenBalance){ el.textContent = 'Rp •••••••'; shownBal = state.balance; renderInsights(); return; }
  var to = state.balance, from = shownBal === null ? to : shownBal;
  shownBal = to;
  renderInsights();
  if(from === to || matchMedia('(prefers-reduced-motion: reduce)').matches){ el.textContent = fmt(to); return; }
  var t0 = performance.now();
  (function step(t){
    var p = Math.min(1, (t - t0) / 650), e = 1 - Math.pow(1 - p, 3);
    el.textContent = fmt(from + (to - from) * e);
    if(p < 1) requestAnimationFrame(step);
  })(t0);
}

/* Transaksi: ikon per kategori + detail */
function renderTxRow(tx){
  var c = CAT_COLOR[catOf(tx)];
  return '<button class="tx-row" onclick="openTx(\'' + tx.id + '\')">' +
    '<div class="tx-ic" style="color:' + c + ';background:color-mix(in srgb,' + c + ' 14%,var(--surface))">' + txIcon(tx.type) + '</div>' +
    '<div class="tx-main"><div class="tx-name">' + tx.name + '</div><div class="tx-sub">' + catOf(tx) + ' · ' + tx.sub + '</div></div>' +
    '<div class="tx-amt ' + tx.type + ' tabular">' + (tx.amount > 0 ? '+' : '') + fmt(tx.amount) + '</div></button>';
}
function openTx(id){
  var t = state.tx.filter(function(x){ return x.id === id; })[0];
  if(!t) return;
  showSheet({
    title: t.type === 'in' ? 'Uang masuk' : 'Uang keluar',
    desc: t.name,
    rows: [['Kategori', catOf(t)], ['Waktu', t.sub], ['Nominal', fmt(Math.abs(t.amount))], ['Status', 'Berhasil'],
           ['No. referensi', 'FND-' + id.replace(/\D/g,'').slice(-8).padStart(8,'0')]],
    primaryLabel: 'Selesai', secondaryLabel: 'Bagikan struk'
  });
  var g = document.querySelector('#sheetBody .btn.ghost');
  if(g) g.onclick = function(){ closeSheet(); toast('Struk dibagikan (simulasi)'); };
}

/* Riwayat dengan pencarian */
var histQuery = '';
function renderHistory(){
  var el = document.getElementById('historyList');
  var f = state.tx.filter(function(t){
    return (historyFilter === 'all' || t.type === historyFilter) &&
           (!histQuery || (t.name + ' ' + catOf(t)).toLowerCase().indexOf(histQuery) > -1);
  });
  el.innerHTML = f.length ? f.map(renderTxRow).join('')
    : '<div class="empty-note">' + (histQuery ? 'Tidak ada transaksi untuk “' + esc(histQuery) + '”' : 'Tidak ada transaksi pada kategori ini') + '</div>';
}

/* Ringkasan pengeluaran */
function renderInsights(){
  if(!state || !document.getElementById('insightCard')) return;
  var inn = 0, out = 0, by = {};
  state.tx.forEach(function(t){
    if(t.amount > 0) inn += t.amount;
    else { out -= t.amount; var c = catOf(t); by[c] = (by[c] || 0) - t.amount; }
  });
  var m = function(n){ return hiddenBalance ? 'Rp •••' : fmt(n); };
  document.getElementById('hsIn').textContent = m(inn);
  document.getElementById('hsOut').textContent = m(out);
  var keys = Object.keys(by).sort(function(a, b){ return by[b] - by[a]; });
  var html = '<div class="ins-tot"><div><small>Total keluar</small><b class="tabular">' + m(out) + '</b></div><div><small>Total masuk</small><b class="tabular" style="color:var(--good)">' + m(inn) + '</b></div></div>';
  if(!out){ html = '<div class="empty-note">Belum ada pengeluaran. Setelah kamu bertransaksi, ringkasannya muncul di sini.</div>'; }
  else {
    html += '<div class="ins-bar">' + keys.map(function(k){ return '<i style="width:' + (by[k] / out * 100) + '%;background:' + CAT_COLOR[k] + '"></i>'; }).join('') + '</div>';
    html += '<div class="ins-leg">' + keys.map(function(k){
      return '<div><em style="background:' + CAT_COLOR[k] + '"></em><span>' + k + '</span><b class="tabular">' + m(by[k]) + '</b><small>' + Math.round(by[k] / out * 100) + '%</small></div>';
    }).join('') + '</div>';
  }
  document.getElementById('insightCard').innerHTML = html;
  renderChart();
}

/* Target tabungan */
function renderGoals(){
  var el = document.getElementById('goalList');
  if(!state.goals.length){ el.innerHTML = '<div class="empty-note">Belum ada target. Buat target pertamamu.</div>'; return; }
  el.innerHTML = state.goals.map(function(g){
    var p = Math.min(100, Math.round(g.saved / g.target * 100)), done = g.saved >= g.target;
    return '<div class="goal"><div class="goal-top"><div><div class="tx-name">' + esc(g.name) + '</div>' +
      '<div class="tx-sub tabular">' + fmt(g.saved) + ' dari ' + fmt(g.target) + '</div></div>' +
      (done ? '<span class="tx-amt in">Tercapai</span>' : '<button class="mini-btn" onclick="topGoal(\'' + g.id + '\')">Isi</button>') +
      '</div><div class="goal-bar"><i class="' + (done ? 'done' : '') + '" style="width:' + p + '%"></i></div>' +
      '<div class="tx-sub">' + p + '%</div></div>';
  }).join('');
}
function topGoal(id){
  var g = state.goals.filter(function(x){ return x.id === id; })[0];
  if(!g) return;
  showAmountEntrySheet({
    title: 'Isi ' + esc(g.name), subtitle: 'Sisa target ' + fmt(g.target - g.saved) + '.', initialAmount: Math.min(100000, g.target - g.saved), min: 1000,
    onConfirm: function(amount){
      requestPin({
        title: 'Konfirmasi Tabungan', subtitle: esc(g.name) + ' · ' + fmt(amount),
        onSuccess: function(){
          g.saved += amount;
          addTransaction('Tabungan ' + g.name, -amount);
          showSheet({ title: g.saved >= g.target ? 'Target tercapai' : 'Tabungan bertambah', desc: g.name,
            rows: [['Nominal', fmt(amount)], ['Terkumpul', fmt(g.saved)], ['Sisa Saldo', fmt(state.balance)]] });
        }
      });
    }
  });
}
function openNewGoal(){
  document.getElementById('sheetBody').innerHTML =
    '<h2>Buat target tabungan</h2><p>Tentukan tujuan dan nominal yang ingin dicapai.</p><div class="stack">' +
    '<div class="field"><label>Nama target</label><input id="goalName" placeholder="Mis. Dana darurat" maxlength="24"></div>' +
    '<div class="field"><label>Nominal target</label><input id="goalTarget" inputmode="numeric" placeholder="Rp 0"></div>' +
    '<span class="field-err" id="goalErr">Isi nama dan nominal target.</span>' +
    '<button class="btn" onclick="saveNewGoal()">Simpan target</button></div>';
  document.getElementById('sheetBackdrop').classList.add('show');
}
function saveNewGoal(){
  var name = document.getElementById('goalName').value.trim(), target = parseAmount(document.getElementById('goalTarget').value);
  if(!name || target < 10000){
    var e = document.getElementById('goalErr'); e.textContent = 'Isi nama dan nominal target minimal Rp 10.000.'; e.classList.add('show'); return;
  }
  state.goals.push({ id: 'g' + Date.now(), name: name, target: target, saved: 0 });
  saveState(); renderGoals(); closeSheet(); toast('Target “' + name + '” dibuat');
}

/* Grafik pergerakan saldo */
function renderChart(){
  var el = document.getElementById('chartCard'); if(!el) return;
  var b = state.balance, pts = [b], n = state.tx.slice(0,7);
  n.forEach(function(t){ b -= t.amount; pts.unshift(b); });
  var W = 340, H = 130, P = 10, mn = Math.min.apply(null, pts), mx = Math.max.apply(null, pts), r = (mx - mn) || 1;
  var xy = pts.map(function(v, i){ return [P + i * (W - 2 * P) / (pts.length - 1), H - P - (v - mn) / r * (H - 2 * P - 14) - 8]; });
  var d = 'M' + xy[0][0] + ',' + xy[0][1];
  for(var i = 1; i < xy.length; i++){ var a = xy[i-1], c = xy[i], m = (a[0] + c[0]) / 2; d += ' C' + m + ',' + a[1] + ' ' + m + ',' + c[1] + ' ' + c[0] + ',' + c[1]; }
  var L = xy[xy.length - 1], delta = pts[pts.length - 1] - pts[0];
  var dots = xy.slice(0, -1).map(function(p){ return `<circle cx="${p[0]}" cy="${p[1]}" r="3" fill="var(--surface)" stroke="var(--accent)" stroke-width="2"/>`; }).join('');
  el.innerHTML = `<div class="ch-top"><div><small>Perubahan saldo</small><b class="tabular" style="color:${delta >= 0 ? 'var(--good)' : 'var(--warn)'}">${hiddenBalance ? 'Rp •••' : (delta >= 0 ? '+' : '') + fmt(delta)}</b></div><small>${n.length} transaksi terakhir</small></div>` +
    `<svg class="chart-svg" viewBox="0 0 ${W} ${H}" role="img" aria-label="Grafik pergerakan saldo"><defs><linearGradient id="cg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="var(--accent)" stop-opacity=".35"/><stop offset="1" stop-color="var(--accent)" stop-opacity="0"/></linearGradient></defs>` +
    `<path d="${d} L${L[0]},${H} L${xy[0][0]},${H}Z" fill="url(#cg)"/><path d="${d}" fill="none" stroke="var(--accent)" stroke-width="3" stroke-linecap="round"/>${dots}` +
    `<circle class="pulse" cx="${L[0]}" cy="${L[1]}" r="5" fill="var(--accent)"/><circle cx="${L[0]}" cy="${L[1]}" r="5" fill="var(--accent)" stroke="var(--surface)" stroke-width="2"/></svg>`;
}

/* Nominal cepat di transfer */
function addTransferAmt(v){
  var el = document.getElementById('transferAmount');
  var n = v ? parseAmount(el.value) + v : 0;
  el.value = n ? n.toLocaleString('id-ID') : '';
}

/* Split Bill */
function openSplit(){
  var names = ['Siti A.', 'Rudi D.', 'Nina K.'];
  document.getElementById('sheetBody').innerHTML = `<h2>Split Bill</h2><p>Bagi tagihan rata dengan temanmu.</p><div class="field"><label>Total tagihan</label><input id="splitTotal" inputmode="numeric" placeholder="Rp 0" oninput="updSplit()"></div><div class="pill-row" id="splitPeople" style="margin-top:14px">` +
    names.map(function(n, i){ return `<button class="pill${i < 2 ? ' active' : ''}" onclick="this.classList.toggle('active');updSplit()">${n}</button>`; }).join('') +
    `</div><div class="split-out" id="splitOut"></div><button class="btn" onclick="sendSplit()">Kirim permintaan</button>`;
  document.getElementById('sheetBackdrop').classList.add('show');
  updSplit();
}
function splitCalc(){
  var tot = parseAmount(document.getElementById('splitTotal').value);
  var who = [].slice.call(document.querySelectorAll('#splitPeople .pill.active')).map(function(p){ return p.textContent; });
  return { tot: tot, who: who, share: who.length ? Math.ceil(tot / (who.length + 1)) : 0 };
}
function updSplit(){
  var c = splitCalc();
  document.getElementById('splitOut').innerHTML = (c.tot && c.who.length)
    ? `<b class="tabular">${fmt(c.share)}</b><small>per orang, dibagi ${c.who.length + 1} orang termasuk kamu</small>`
    : '<small>Isi total tagihan dan pilih minimal satu teman.</small>';
}
function sendSplit(){
  var c = splitCalc();
  if(!c.tot || !c.who.length){ toast('Isi total tagihan dan pilih teman dulu', true); return; }
  closeSheet();
  toast('Permintaan ' + fmt(c.share) + ' dikirim ke ' + c.who.length + ' teman');
  c.who.forEach(function(n, i){
    setTimeout(function(){ addTransaction('Patungan dari ' + n, c.share); toast(n + ' sudah bayar ' + fmt(c.share)); }, 2800 * (i + 1));
  });
}

/* ===== Tahap 3: JS ===== */
function buzz(p){ try{ navigator.vibrate && navigator.vibrate(p); }catch(e){} }
function skeleton(ids){
  if(matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  ids.forEach(function(id){ var el = document.getElementById(id); if(!el) return; el.classList.add('skel'); setTimeout(function(){ el.classList.remove('skel'); }, 650); });
}
var _go = go; go = function(n){ _go(n); if(n === 'history') skeleton(['historyList']); if(n === 'invest') skeleton(['goalList']); };
var _pp = pinPress; pinPress = function(d){ buzz(8); _pp(d); };

function defaultBills(){ return [{id:'b1',name:'Listrik',amount:245000,due:'25 Nov'},{id:'b2',name:'BPJS',amount:150000,due:'28 Nov'},{id:'b3',name:'Paket Data',amount:65000,due:'30 Nov'}]; }
function defaultNotifs(){ return [{t:'Tagihan listrik jatuh tempo',d:'Rp 245.000 · 25 Nov',time:'Hari ini',r:0},{t:'Target Liburan Bali baru 25%',d:'Isi lagi supaya tepat waktu',time:'Kemarin',r:0}]; }
function ensureState(){
  if(!state.goals) state.goals = defaultGoals();
  if(!state.budgets) state.budgets = {QRIS:300000,Tagihan:800000,Transfer:600000,Tabungan:500000};
  if(!state.bills) state.bills = defaultBills();
  if(!state.notifs){ state.notifs = defaultNotifs(); state.notifCount = 2; }
  if(!state.v2){ state.v2 = 1; var ord = {t1:5,t2:4,t3:3,t4:2,t5:1}; state.tx.sort(function(a,b){ return (ord[b.id]||99) - (ord[a.id]||99); }); }
}

/* Efek sukses */
var _ss = showSheet;
showSheet = function(cfg){
  _ss(cfg);
  var ic = document.querySelector('#sheetBody .sheet-icon'); if(ic) ic.classList.add('ok');
  if(/Berhasil|bertambah|tercapai/i.test(cfg.title || '')){ buzz([30,40,30]); confetti(); }
};
function confetti(){
  if(matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  var cols = ['#FF7A1A','#FFB567','#1F9254','#2F7DD1','#E0457B'];
  for(var i = 0; i < 28; i++){
    var e = document.createElement('i'), a = Math.random() * 6.283, r = 90 + Math.random() * 130;
    e.className = 'cf';
    e.style.cssText = '--x:' + Math.cos(a) * r + 'px;--y:' + (Math.sin(a) * r - 60) + 'px;--r:' + (Math.random() * 720 - 360) + 'deg;background:' + cols[i % 5];
    document.body.appendChild(e);
    setTimeout(function(x){ x.remove(); }, 1200, e);
  }
}

/* Riwayat berkelompok */
function dayGroup(t){ var d = parseInt(t.sub.split(' · ')[0], 10); if(isNaN(d)) return 'Hari ini'; var df = 21 - d; return df <= 0 ? 'Hari ini' : df === 1 ? 'Kemarin' : df <= 7 ? 'Minggu ini' : 'Lebih lama'; }
function renderHistory(){
  var el = document.getElementById('historyList');
  var f = state.tx.filter(function(t){ return (historyFilter === 'all' || t.type === historyFilter) && (!histQuery || (t.name + ' ' + catOf(t)).toLowerCase().indexOf(histQuery) > -1); });
  var groups = [], idx = {};
  f.forEach(function(t){ var g = dayGroup(t); if(!(g in idx)){ idx[g] = groups.length; groups.push({g:g,t:[]}); } groups[idx[g]].t.push(t); });
  el.innerHTML = groups.length ? groups.map(function(G){
    var s = G.t.reduce(function(a, t){ return a + t.amount; }, 0);
    return `<div class="grp"><span>${G.g}</span><b class="tabular">${s > 0 ? '+' : ''}${fmt(s)}</b></div>` + G.t.map(renderTxRow).join('');
  }).join('') : '<div class="empty-note">' + (histQuery ? 'Tidak ada transaksi untuk “' + esc(histQuery) + '”' : 'Tidak ada transaksi pada kategori ini') + '</div>';
}

/* Grafik interaktif */
var _rc = renderChart; renderChart = function(){ _rc(); bindChart(); };
function bindChart(){
  var el = document.getElementById('chartCard'), svg = el && el.querySelector('svg'); if(!svg) return;
  var b = state.balance, pts = [b], n = state.tx.slice(0,7);
  n.forEach(function(t){ b -= t.amount; pts.unshift(b); });
  var mn = Math.min.apply(null, pts), mx = Math.max.apply(null, pts), r = (mx - mn) || 1, W = 340, H = 130, P = 10;
  var lab = el.querySelector('.ch-top>small'), orig = lab.textContent, NS = 'http://www.w3.org/2000/svg';
  var ln = document.createElementNS(NS, 'line'), dt = document.createElementNS(NS, 'circle');
  ln.style.stroke = 'var(--muted)'; ln.setAttribute('stroke-dasharray', '3 3'); ln.style.display = 'none';
  dt.setAttribute('r', 6); dt.style.fill = 'var(--surface)'; dt.style.stroke = 'var(--accent)'; dt.setAttribute('stroke-width', 3); dt.style.display = 'none';
  svg.appendChild(ln); svg.appendChild(dt);
  function show(e){
    var q = svg.getBoundingClientRect(), x = (e.clientX - q.left) / q.width * W;
    var i = Math.max(0, Math.min(pts.length - 1, Math.round((x - P) / (W - 2 * P) * (pts.length - 1))));
    var px = P + i * (W - 2 * P) / (pts.length - 1), py = H - P - (pts[i] - mn) / r * (H - 2 * P - 14) - 8;
    ln.setAttribute('x1', px); ln.setAttribute('x2', px); ln.setAttribute('y1', 0); ln.setAttribute('y2', H); ln.style.display = '';
    dt.setAttribute('cx', px); dt.setAttribute('cy', py); dt.style.display = '';
    lab.textContent = (i ? n[n.length - i].name : 'Saldo awal') + ' · ' + (hiddenBalance ? 'Rp •••' : fmt(pts[i]));
  }
  svg.addEventListener('pointermove', show); svg.addEventListener('pointerdown', show);
  svg.addEventListener('pointerleave', function(){ ln.style.display = 'none'; dt.style.display = 'none'; lab.textContent = orig; });
  svg.style.touchAction = 'pan-y';
}

/* Notifikasi */
function pushNotif(t, d){
  state.notifs.unshift({t:t, d:d, time:nowLabel(), r:0});
  state.notifs = state.notifs.slice(0, 30);
  state.notifCount = state.notifs.filter(function(x){ return !x.r; }).length;
  saveState(); renderNotif();
}
function openNotif(){
  var l = state.notifs;
  document.getElementById('sheetBody').innerHTML = '<h2>Notifikasi</h2><p>Aktivitas terbaru akunmu</p>' +
    (l.length ? l.map(function(n){ return `<div class="notif${n.r ? '' : ' new'}"><b>${esc(n.t)}</b><span>${esc(n.d)}</span><small>${esc(n.time)}</small></div>`; }).join('') : '<div class="empty-note">Belum ada notifikasi.</div>') +
    '<button class="btn ghost" style="margin-top:12px" onclick="closeSheet()">Tutup</button>';
  l.forEach(function(n){ n.r = 1; });
  state.notifCount = 0; saveState(); renderNotif();
  document.getElementById('sheetBackdrop').classList.add('show');
}
var _at = addTransaction;
addTransaction = function(name, amt){
  var before = spentBy();
  _at(name, amt);
  pushNotif(amt > 0 ? 'Uang masuk' : 'Pembayaran berhasil', name + ' · ' + fmt(Math.abs(amt)));
  if(amt < 0){
    var c = catOf({name:name}), lim = state.budgets[c], after = spentBy()[c] || 0, prev = before[c] || 0;
    if(lim && after >= lim && prev < lim) pushNotif('Anggaran ' + c + ' terlampaui', fmt(after) + ' dari batas ' + fmt(lim));
    else if(lim && after >= lim * .85 && prev < lim * .85) pushNotif('Anggaran ' + c + ' hampir habis', 'Sudah terpakai ' + Math.round(after / lim * 100) + '%');
  }
};

/* Anggaran */
function spentBy(){ var by = {}; state.tx.forEach(function(t){ if(t.amount < 0){ var c = catOf(t); by[c] = (by[c] || 0) - t.amount; } }); return by; }
function renderBudget(){
  var el = document.getElementById('budgetCard'); if(!el) return;
  var by = spentBy();
  el.innerHTML = Object.keys(state.budgets).map(function(c){
    var lim = state.budgets[c], s = by[c] || 0, p = Math.round(s / lim * 100), col = p >= 100 ? 'var(--warn)' : p >= 85 ? '#E0A100' : CAT_COLOR[c];
    return `<button class="bud" onclick="openBudget('${c}')"><div class="goal-top"><span class="tx-name">${c}</span><span class="tx-sub tabular">${fmt(s)} / ${fmt(lim)}</span></div><div class="goal-bar"><i style="width:${Math.min(100, p)}%;background:${col}"></i></div></button>`;
  }).join('');
}
function openBudget(c){
  document.getElementById('sheetBody').innerHTML = `<h2>Anggaran ${c}</h2><p>Atur batas pengeluaran bulanan.</p><div class="field"><label>Batas bulanan</label><input id="budInput" inputmode="numeric" value="${state.budgets[c].toLocaleString('id-ID')}"></div><button class="btn" style="margin-top:14px" onclick="saveBudget('${c}')">Simpan anggaran</button>`;
  document.getElementById('sheetBackdrop').classList.add('show');
}
function saveBudget(c){
  var v = parseAmount(document.getElementById('budInput').value);
  if(v < 10000){ toast('Batas minimal Rp 10.000', true); return; }
  state.budgets[c] = v; saveState(); renderBudget(); closeSheet(); toast('Anggaran ' + c + ' disimpan');
}

/* Tagihan terjadwal */
function renderBills(){
  var el = document.getElementById('billList'); if(!el) return;
  el.innerHTML = state.bills.length ? state.bills.map(function(x){
    return `<div class="goal-top" style="padding:12px 0;border-bottom:1px solid var(--line)"><div><div class="tx-name">${esc(x.name)}</div><div class="tx-sub tabular">Jatuh tempo ${x.due} · ${fmt(x.amount)}</div></div><button class="mini-btn" onclick="payBill('${x.id}')">Bayar</button></div>`;
  }).join('') : '<div class="empty-note">Semua tagihan sudah lunas.</div>';
}
function payBill(id){
  var x = state.bills.filter(function(b){ return b.id === id; })[0]; if(!x) return;
  if(x.amount > state.balance){ toast('Saldo tidak cukup untuk membayar ' + x.name, true); return; }
  requestPin({ title: 'Bayar ' + x.name, subtitle: fmt(x.amount), onSuccess: function(){
    state.bills = state.bills.filter(function(b){ return b.id !== id; });
    addTransaction('Tagihan ' + x.name, -x.amount);
    showSheet({ title: 'Pembayaran Berhasil', desc: 'Tagihan ' + x.name + ' lunas.', rows: [['Nominal', fmt(x.amount)], ['Sisa Saldo', fmt(state.balance)]] });
  }});
}

/* Scan QRIS */
var scanTimer = null;
function simulateScan(){
  var amount = parseAmount(document.getElementById('qrisAmount').value);
  if(!amount){ toast('Masukkan nominal pembayaran', true); return; }
  if(amount > state.balance){ toast('Pembayaran gagal: saldo tidak cukup', true); return; }
  var o = document.createElement('div'); o.className = 'scan'; o.id = 'scanOv';
  o.innerHTML = '<div class="scan-frame"><i></i><i></i><i></i><i></i><span class="scan-line"></span></div><p style="margin:0">Arahkan kamera ke kode QRIS</p><button class="mini-btn" onclick="closeScan()">Batal</button>';
  document.body.appendChild(o);
  scanTimer = setTimeout(function(){ closeScan(); pickMerchant(amount); }, 2000);
}
function closeScan(){ clearTimeout(scanTimer); var o = document.getElementById('scanOv'); if(o) o.remove(); }
function pickMerchant(amount){
  buzz(20);
  document.getElementById('sheetBody').innerHTML = '<h2>Kode terdeteksi</h2><p>Pilih merchant untuk membayar ' + fmt(amount) + '</p>' +
    ['Kopi Senja','Warung Bu Tini','Toko Maju'].map(function(m){
      return `<button class="contact-row" data-n="${m}" onclick="payQris(this.dataset.n,${amount})"><div class="avatar">${m.charAt(0)}</div><div><div class="tx-name">${m}</div><div class="tx-sub">Terverifikasi QRIS</div></div></button>`;
    }).join('');
  document.getElementById('sheetBackdrop').classList.add('show');
}
function payQris(m, amount){
  closeSheet();
  requestPin({ title: 'Konfirmasi QRIS', subtitle: 'Bayar ' + fmt(amount) + ' ke ' + m, onSuccess: function(){
    addTransaction('QRIS - ' + m, -amount);
    showSheet({ title: 'Pembayaran QRIS Berhasil', desc: 'Transaksi telah dicatat ke riwayat.', rows: [['Merchant', m], ['Nominal', fmt(amount)], ['Sisa Saldo', fmt(state.balance)]] });
  }});
}

/* Tarik dana investasi */
function openWithdraw(){
  if(state.investTotal <= 0){ toast('Belum ada dana investasi untuk ditarik', true); return; }
  document.getElementById('sheetBody').innerHTML = `<div class="sheet-icon" style="color:var(--accent)"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12l7 7 7-7"/></svg></div><h2>Tarik dana investasi</h2><p>Dana langsung cair ke Saldo Fonder.</p><div class="field"><label>Nominal penarikan</label><input id="wdAmt" inputmode="numeric" placeholder="Rp 0"></div><div class="pill-row chips"><button class="pill" onclick="setWd(.25)">25%</button><button class="pill" onclick="setWd(.5)">50%</button><button class="pill" onclick="setWd(1)">Semua</button></div><span class="field-err" id="wdErr"></span><div class="sheet-row"><span class="k">Dana tersedia</span><span class="v">${fmt(state.investTotal)}</span></div><button class="btn" style="margin-top:14px" onclick="confirmWd()">Lanjutkan</button>`;
  document.getElementById('sheetBackdrop').classList.add('show');
}
function setWd(f){ document.getElementById('wdAmt').value = Math.round(state.investTotal * f).toLocaleString('id-ID'); }
function confirmWd(){
  var amt = parseAmount(document.getElementById('wdAmt').value), err = document.getElementById('wdErr');
  if(amt < 10000 || amt > state.investTotal){
    err.textContent = amt > state.investTotal ? 'Melebihi dana tersedia ' + fmt(state.investTotal) + '.' : 'Minimal penarikan Rp 10.000.';
    err.classList.add('show'); return;
  }
  closeSheet();
  requestPin({ title: 'Konfirmasi Penarikan', subtitle: 'Tarik ' + fmt(amt) + ' dari investasi', onSuccess: function(){
    state.investTotal -= amt;
    addTransaction('Investasi · Pencairan dana', amt);
    showSheet({ title: 'Penarikan Berhasil', desc: 'Dana sudah masuk ke Saldo Fonder.', rows: [['Nominal', fmt(amt)], ['Sisa Investasi', fmt(state.investTotal)], ['Saldo Sekarang', fmt(state.balance)]] });
  }});
}

/* Format ribuan otomatis pada kolom nominal */
document.addEventListener('input', function(e){
  var t = e.target;
  if(t.tagName === 'INPUT' && t.getAttribute('inputmode') === 'numeric' && t.id !== 'transferNumber'){
    var n = parseAmount(t.value); t.value = n ? n.toLocaleString('id-ID') : '';
  }
});

function renderAll(){
  ensureState(); applyTheme(); renderBalance(); renderHome(); renderHistory(); renderInvest(); renderNotif(); renderGoals(); renderGreet(); renderBudget(); renderBills();
}

/* ======================= Boot ======================= */
function start(){
  state = loadState();
  renderAll();
  initRoute();
  requestPin({
    title: 'Masuk ke Fonder',
    subtitle: 'Masukkan PIN untuk melanjutkan',
    lock: true,
    onSuccess: function(){ shownBal = 0; renderBalance(); skeleton(['chartCard','insightCard','budgetCard','homeTxList']); }
  });
}
if(window.claude && window.claude.hot && window.claude.hot.ready){
  window.claude.hot.ready(start);
} else {
  start();
}
